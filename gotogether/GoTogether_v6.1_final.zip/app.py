import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from datetime import datetime
import random

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXT = {'png','jpg','jpeg','gif','svg'}

app = Flask(__name__)
app.secret_key = 'dev-secret-key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# In-memory sample data (photo fields intentionally empty to show text-only)
conductores = [
    {'id':1,'name':'Laura Gómez','email':'laura@icesi.edu','model':'Mazda 3','plate':'HBG-214','route':'Ciudad Jardín → Icesi','photo':'','city':'Cali'},
    {'id':2,'name':'Andrés Torres','email':'andres@javeriana.edu','model':'Renault Logan','plate':'JKL-980','route':'Valle del Lili → Javeriana','photo':'','city':'Cali'},
    {'id':3,'name':'Camila Rivas','email':'camila@univalle.edu','model':'Kia Picanto','plate':'ZXP-111','route':'Palmira → Univalle','photo':'','city':'Palmira'}
]

pasajeros = [
    {'id':1,'name':'Nicolás Jiménez','email':'nico@javeriana.edu','university':'Javeriana','destination':'Javeriana','time':'07:00 AM','neighborhood':'Valle del Lili','photo':'','city':'Cali'},
    {'id':2,'name':'Daniela Cobo','email':'daniela@univalle.edu','university':'Univalle','destination':'Univalle','time':'07:30 AM','neighborhood':'Palmira','photo':'','city':'Palmira'}
]

servicios = []  # {'id','driver_id','passenger_id','time','price','state'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

def format_price_by_city(city):
    # return price string like '8.5k COP'
    if city and city.lower() == 'cali':
        value = random.uniform(4.0,9.0)
        return f"{value:.1f}k COP"
    else:
        value = random.uniform(12.0,20.0)
        return f"{value:.1f}k COP"

@app.route('/')
def splash():
    return render_template('splash.html')

@app.route('/menu')
def menu():
    return render_template('menu.html')

@app.route('/register_driver', methods=['GET','POST'])
def register_driver():
    if request.method == 'POST':
        name = request.form.get('name','Conductor')
        email = request.form.get('email','user@uni.edu')
        model = request.form.get('model','Vehículo')
        plate = request.form.get('plate','XXX-000')
        route = request.form.get('route','Ruta')
        city = request.form.get('city','Cali')
        photo = request.files.get('photo')
        filename = ''
        if photo and allowed_file(photo.filename):
            filename = secure_filename(photo.filename)
            photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        new_id = max([c['id'] for c in conductores]) + 1 if conductores else 1
        conductores.append({'id':new_id,'name':name,'email':email,'model':model,'plate':plate,'route':route,'photo':filename,'city':city})
        flash('Conductor registrado correctamente.', 'success')
        return redirect(url_for('home_driver', driver_id=new_id))
    return render_template('register_driver.html')

@app.route('/register_passenger', methods=['GET','POST'])
def register_passenger():
    if request.method == 'POST':
        name = request.form.get('name','Pasajero')
        email = request.form.get('email','user@uni.edu')
        university = request.form.get('university','Universidad')
        destination = request.form.get('destination','Destino')
        time = request.form.get('time','07:00 AM')
        neighborhood = request.form.get('neighborhood','Barrio')
        city = request.form.get('city','Cali')
        photo = request.files.get('photo')
        filename = ''
        if photo and allowed_file(photo.filename):
            filename = secure_filename(photo.filename)
            photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        new_id = max([p['id'] for p in pasajeros]) + 1 if pasajeros else 1
        pasajeros.append({'id':new_id,'name':name,'email':email,'university':university,'destination':destination,'time':time,'neighborhood':neighborhood,'photo':filename,'city':city})
        flash('Pasajero registrado correctamente.', 'success')
        return redirect(url_for('home_passenger', passenger_id=new_id))
    return render_template('register_passenger.html')

@app.route('/home_driver/<int:driver_id>')
def home_driver(driver_id):
    driver = next((c for c in conductores if c['id']==driver_id), None)
    # drivers see all passengers needing trips
    my_services = [s for s in servicios if s.get('driver_id')==driver_id and s.get('state')!='completed']
    return render_template('home_driver.html', driver=driver, pasajeros=pasajeros, servicios=my_services)

@app.route('/home_passenger/<int:passenger_id>')
def home_passenger(passenger_id):
    passenger = next((p for p in pasajeros if p['id']==passenger_id), None)
    # show drivers whose route matches passenger.destination or passenger.university (case-insensitive)
    def matches_route(driver, passenger):
        dest = passenger.get('destination','').lower()
        uni = passenger.get('university','').lower()
        route = driver.get('route','').lower()
        return (dest and dest in route) or (uni and uni in route)
    matched_drivers = [d for d in conductores if matches_route(d, passenger)]
    drivers_to_show = matched_drivers if matched_drivers else conductores
    my_services = [s for s in servicios if s.get('passenger_id')==passenger_id and s.get('state')!='completed']
    return render_template('home_passenger.html', passenger=passenger, conductores=drivers_to_show, servicios=my_services)

@app.route('/directory')
def directory():
    # shows all profiles and their routes for both conductores and pasajeros
    role = request.args.get('role')  # optional: 'driver' or 'passenger' or None
    self_id = request.args.get('self_id', type=int)
    return render_template('directory.html', conductores=conductores, pasajeros=pasajeros, role=role, self_id=self_id)

@app.route('/schedule_service', methods=['POST'])
def schedule_service():
    data = request.form.to_dict()
    role = data.get('role')
    self_id = int(data.get('self_id',0))
    target_id = int(data.get('target_id',0))
    if role=='driver':
        driver_id = self_id
        passenger_id = target_id
    else:
        driver_id = target_id
        passenger_id = self_id
    now = datetime.now().strftime('%I:%M:%S %p')  # 12-hour format with AM/PM
    p = next((p for p in pasajeros if p['id']==passenger_id), None)
    city = p.get('city') if p else None
    price = format_price_by_city(city)
    servicio = {'id': len(servicios)+1, 'driver_id': driver_id, 'passenger_id': passenger_id, 'time': now, 'price': price, 'state':'pending'}
    servicios.append(servicio)
    return jsonify({'status':'ok','message':'Servicio programado','servicio':servicio})

@app.route('/my_trips/<int:driver_id>')
def my_trips(driver_id):
    my_services = [s for s in servicios if s.get('driver_id')==driver_id and s.get('state')!='completed']
    my_services_sorted = sorted(my_services, key=lambda x: x.get('time'))
    result = []
    for s in my_services_sorted:
        p = next((p for p in pasajeros if p['id']==s['passenger_id']), None)
        if p:
            result.append({'service':s,'passenger':p})
    return render_template('my_trips.html', services=result, driver_id=driver_id)

@app.route('/complete_service', methods=['POST'])
def complete_service():
    sid = int(request.form.get('service_id',0))
    for s in servicios:
        if s['id']==sid:
            s['state']='completed'
            break
    return jsonify({'status':'ok'})

@app.route('/chat_simulate', methods=['POST'])
def chat_simulate():
    data = request.form.to_dict()
    msg = data.get('message','')
    sender = data.get('sender','Usuario')
    reply = f"{sender}: {msg} (mensaje enviado)"
    return jsonify({'status':'ok','reply':reply})

@app.route('/reset', methods=['POST'])
def reset():
    folder = app.config['UPLOAD_FOLDER']
    for f in os.listdir(folder):
        path = os.path.join(folder, f)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass
    flash('Datos temporales y uploads eliminados. Reinicia la app para recargar ejemplos.', 'info')
    return redirect(url_for('splash'))

if __name__ == '__main__':
    app.run(debug=True)
