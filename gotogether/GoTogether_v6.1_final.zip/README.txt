GoTogether v6.1 Final — Directory & Filtering

Ejecutar:
  pip install -r requirements.txt
  python app.py
Abre http://127.0.0.1:5000
